04 Aug 2022
Logan Govender test

1. Created a .net core 3.1 Restful api
	- It uses merchant api key authentication and JWT token auth to allow external vendors and app users to use the features
	- The merchant creds are stored in appsettings for now, it should reside in either vault like secret server etc.
	- Unit tests are included.
	- Also catered for docker support, whihc can be pushed to a container registry and later on used in devops to deploy into cloud k8s enviornment

2. Created a Angular 8 app that intergates with the restful api using jwt auth tokens.
	- Started the design of adding a proxy ap that will interact with the api(didnt get a chance to complete it), instead of UI talking directly to the api. This is to make it mroe secure(server to server api calls). So i had 
		include api keys in frontend...which is not the solution, hence the proxy api.


3. To run :
	- The api projects needs vs 2019...Open, build and run
	- For the angular project, open the project and install the node modules