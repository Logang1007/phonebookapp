﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Options;
using Phonebook.API.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Phonebook.API.Filters
{
    public class SecurityMiddleware : Attribute, IAsyncActionFilter
    {
        private const string _apiKeyName = "ApiKey";
        private const string _merchKeyName = "MerchName";
        public async Task OnActionExecutionAsync(ActionExecutingContext context, ActionExecutionDelegate next)
        {
            var resp = new BaseResponseModel();
            if (!context.HttpContext.Request.Headers.TryGetValue(_apiKeyName, out var extractedApiKey))
            {

                resp.IsSuccess = false;
                resp.Message = "ApiKey not present";
                resp.Code = "D001";
                context.Result = new ObjectResult(resp)
                {
                    StatusCode = 401
                };
                return;
            }
            if (!context.HttpContext.Request.Headers.TryGetValue(_merchKeyName, out var extractedMerchName))
            {
                resp.IsSuccess = false;
                resp.Message = "MerchName not present";
                resp.Code = "D002";
                context.Result = new ObjectResult(resp)
                {
                    StatusCode = 401
                };
                return;
            }

            var appSettings = context.HttpContext.RequestServices.GetRequiredService<IOptions<AppSettingsModel>>();
            if(appSettings.Value.MerchantSecurity.Count() == 0)
            {
                resp.IsSuccess = false;
                resp.Message = "Fatal API error. No merchant setup";
                resp.Code = "D003";
                context.Result = new ObjectResult(resp)
                {
                    StatusCode = 401
                };
                return;
            }
            var result = appSettings.Value.MerchantSecurity.Any(x=>x.IsEnabled && x.ApiKey== extractedApiKey && x.MerchantName == extractedMerchName);
            if (!result)
            {
                resp.IsSuccess = false;
                resp.Message = "Invalid merchant credentials";
                resp.Code = "D004";
                context.Result = new ObjectResult(resp)
                {
                    StatusCode = 401
                };
                return;
            }

            await next();
        }
    }
}

