﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.AspNetCore.Mvc.ModelBinding;
using Phonebook.API.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Phonebook.API.Filters
{
    public class ValidationFilter: Attribute, IAsyncActionFilter
    {
       
        public async Task OnActionExecutionAsync(ActionExecutingContext context, ActionExecutionDelegate next)
        {
            var resp = new BaseResponseModel();
            if (!context.ModelState.IsValid)
            {
                StringBuilder sbErrors = new StringBuilder();
                foreach (var modelState in context.ModelState.Values)
                {
                    foreach (ModelError error in modelState.Errors)
                    {
                        sbErrors.Append(error.ErrorMessage+",");
                    }
                }
                resp.IsSuccess = false;
                resp.Message = $"Data is invalid :{sbErrors.ToString()}";
                context.Result = new ObjectResult(resp)
                {
                    StatusCode = 400
                };
                return;
            }
            

            await next();
        }
    }
}
