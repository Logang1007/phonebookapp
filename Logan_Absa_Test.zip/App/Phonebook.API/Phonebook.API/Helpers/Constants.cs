﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Phonebook.API.Helpers
{
    public class Constants
    {
        public static string GetDBPath(string sqlLiteConnection)
        {
            var path = System.IO.Path.GetDirectoryName(
                System.Reflection.Assembly.GetExecutingAssembly().GetName().CodeBase).Replace("file:\\", "");
            var fullDbPath = $"Data Source={path}\\{sqlLiteConnection}";

            return fullDbPath;
        }
    }
}
