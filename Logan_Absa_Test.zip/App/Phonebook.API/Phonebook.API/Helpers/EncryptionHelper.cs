﻿using Phonebook.API.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Threading.Tasks;

namespace Phonebook.API.Helpers
{
    public class EncryptionHelper: IEncryptionHelper
    {

        public string HashText(string input)
        {
            using (var sha = new SHA256Managed())
            {
                byte[] textData = System.Text.Encoding.UTF8.GetBytes(input);
                byte[] hash = sha.ComputeHash(textData);
                return BitConverter.ToString(hash).Replace("-", String.Empty);
            }


        }
    }
}
