﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Phonebook.API.Helpers
{
    public class PhonebookException : Exception
    {
        public PhonebookException()
        {
        }

        public PhonebookException(string message)
            : base(message)
        {
        }

        public PhonebookException(string message, Exception inner)
            : base(message, inner)
        {
        }
    }
}
