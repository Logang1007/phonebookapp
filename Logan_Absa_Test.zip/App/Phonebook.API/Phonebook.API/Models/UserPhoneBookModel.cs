﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Phonebook.API.Models
{
    public class UserPhoneBookModel
    {
        [Required]
        public int UserID { get; set; }
        public int EntryID { get; set; }
        public DateTime DateAdded { get; set; }
        public bool IsActive { get; set; }
        public int UserPhoneBookRowID { get; set; }

    }
}
