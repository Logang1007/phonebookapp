﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Phonebook.API.Models
{
    public class BaseResponseModel
    {
        public bool IsSuccess { get; set; } = true;
        public string Message { get; set; } = "Success";
        public string Code { get; set; } = "A001";
        public bool IsTokenExpired { get; set; }
        public string Token { get; set; }
    }
}
