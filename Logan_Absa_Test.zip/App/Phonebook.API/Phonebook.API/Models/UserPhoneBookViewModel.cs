﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Phonebook.API.Models
{
    public class UserPhoneBookViewModel: UserPhoneBookModel
    {
        public string Firstname { get; set; }
        public string Lastname { get; set; }
        public string Username { get; set; }

        [Required]
        public string EntryName { get; set; }

        [Required]
        public string PhoneNumber { get; set; }
        public string Token { get; set; }

    }
}
