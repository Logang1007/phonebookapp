﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Phonebook.API.Models
{
    public class UserResponseModel: BaseResponseModel
    {
        public UserModel User { get; set; } = new UserModel();
    }
}
