﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Phonebook.API.Models
{
    public class AppSettingsModel
    {
        public string SqlLiteConnection { get; set; }
        public int LoginTokenExpiryMinutes { get; set; }
        public JWT Jwt { get; set; } = new JWT();
        public List<MerchantSecurity> MerchantSecurity { get; set; } = new List<MerchantSecurity>();
        public bool IsInMemoryDB { get; set; }
        public string InMemoryDBPath { get; set; }
    }

    public class JWT
    {
        public string Key { get; set; }
        public string Issuer { get; set; }
        public string Audience { get; set; }
    }


    public class MerchantSecurity {
        public string MerchantName { get; set; }
        public string ApiKey { get; set; }
        public bool IsEnabled { get; set; }
    }

}
