﻿using Dapper;
using Microsoft.Data.Sqlite;
using Microsoft.Extensions.Options;
using Phonebook.API.Interface;
using Phonebook.API.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Phonebook.API.DataLayer.Repositories
{
    public class PhonebookRepository: IPhonebookRepository
    {
        private readonly AppSettingsModel _appSettingsModel;

        public PhonebookRepository(IOptions<AppSettingsModel> appSettingsModel)
        {
            _appSettingsModel = appSettingsModel.Value;
        }


        private string _getConnectionString()
        {
            if (_appSettingsModel.IsInMemoryDB)
            {
                return _appSettingsModel.InMemoryDBPath;
            
            }
            else
            {
                var path = System.IO.Path.GetDirectoryName(
                    System.Reflection.Assembly.GetExecutingAssembly().GetName().CodeBase).Replace("file:\\", "");
                var fullDbPath = $"Data Source={path}\\{_appSettingsModel.SqlLiteConnection}";
                return fullDbPath;
            }
            
        }
        public async Task CreateUser(UserModel userModel)
        {
            var parameterForUser = new DynamicParameters();
            parameterForUser.Add("@Firstname", userModel.Firstname);
            parameterForUser.Add("@Lastname", userModel.Lastname);
            parameterForUser.Add("@Username", userModel.Username);
            parameterForUser.Add("@Password", userModel.Password);
            parameterForUser.Add("@DateAdded", DateTime.UtcNow);

            using (var connection = new SqliteConnection(_getConnectionString()))
            {
                await connection.ExecuteAsync("INSERT INTO Users (Firstname, Lastname, Username, Password, DateAdded)" +
                "VALUES (@Firstname, @Lastname, @Username, @Password, @DateAdded);", parameterForUser);
            }
        }

        public async Task<UserModel> GetUserById(int userId)
        {
            var parameters = new DynamicParameters();
            parameters.Add("@UserID", userId);

            using (var connection = new SqliteConnection(_getConnectionString()))
            {
                var result = await connection.QueryFirstOrDefaultAsync<UserModel>("SELECT rowId as UserID, u.Firstname, u.Lastname, u.Username FROM  Users u WHERE u.rowid = @UserID", parameters);
                if (result == null)
                {
                    return null;
                }

                return result;
            }
        }

        public async Task<UserModel> GetUserByUsername(string userName)
        {
            var parameters = new DynamicParameters();
            parameters.Add("@UserName", userName);

            using (var connection = new SqliteConnection(_getConnectionString()))
            {
                var result = await connection.QueryFirstOrDefaultAsync<UserModel>("SELECT rowId as UserID, u.Firstname, u.Lastname, u.Username FROM  Users u WHERE u.Username = @UserName", parameters);
                if (result == null)
                {
                    return null;
                }

                return result;
            }
        }

        public async Task<UserModel> GetUserByCredentials(string userName, string passwordHashed)
        {
            var parameters = new DynamicParameters();
            parameters.Add("@UserName", userName);
            parameters.Add("@Password", passwordHashed);

            using (var connection = new SqliteConnection(_getConnectionString()))
            {
                var result = await connection.QueryFirstOrDefaultAsync<UserModel>("SELECT rowId as UserID, u.Firstname, u.Lastname, u.Username FROM  Users u WHERE u.Username = @UserName AND u.Password = @Password", parameters);
                if (result == null)
                {
                    return null;
                }

                return result;
            }
        }


        public async Task CreateUserPhoneBookEntry(UserPhoneBookViewModel userPhoneBookViewModel)
        {
            var parameterForEntry = new DynamicParameters();
            parameterForEntry.Add("@Name", userPhoneBookViewModel.EntryName);
            parameterForEntry.Add("@PhoneNumber", userPhoneBookViewModel.PhoneNumber);
            parameterForEntry.Add("@DateAdded", DateTime.UtcNow);

            var parameterForUserEntry = new DynamicParameters();
            parameterForUserEntry.Add("@UserID", userPhoneBookViewModel.UserID);
            parameterForUserEntry.Add("@DateAdded", DateTime.UtcNow);
            parameterForUserEntry.Add("@IsActive", true);

            using (var connection = new SqliteConnection(_getConnectionString()))
            {

                await connection.ExecuteAsync("INSERT INTO PhoneBookEntry (Name, PhoneNumber, DateAdded)" +
                "VALUES (@Name, @PhoneNumber, @DateAdded);", parameterForEntry);

                var newEntryId =  await connection.QueryFirstOrDefaultAsync<long>("SELECT last_insert_rowid() FROM PhoneBookEntry;");

                parameterForUserEntry.Add("@EntryID", newEntryId);

                await connection.ExecuteAsync("INSERT INTO UserPhoneBook (UserID, EntryID, DateAdded, IsActive)" +
               "VALUES (@UserID, @EntryID, @DateAdded, @IsActive);", parameterForUserEntry);
            }
        }

        public async Task<List<UserPhoneBookViewModel>> GetEntriesByUser(int userId)
        {
            var parameters = new DynamicParameters();
            parameters.Add("@UserID", userId);

            using (var connection = new SqliteConnection(_getConnectionString()))
            {
                var result = await connection.QueryAsync<UserPhoneBookViewModel>("SELECT up.rowid AS UserPhoneBookRowID, u.Firstname, u.Lastname, u.Username, u.ROWID AS UserID , pb.Name AS EntryName, pb.PhoneNumber, pb.DateAdded, up.EntryID from UserPhoneBook up" +
                "  INNER JOIN PhoneBookEntry pb ON pb.ROWID = up.EntryID INNER JOIN Users u ON u.ROWID = up.UserID WHERE up.IsActive = 1 AND up.UserID = @UserID;", parameters);
                if(result == null)
                {
                    return new List<UserPhoneBookViewModel>();
                }

                return result.ToList();
            }
        }

        public async Task DeleteUserPhoneBookEntry(int userPhoneBookRowID)
        {
            var parameterForUser = new DynamicParameters();
            parameterForUser.Add("@UserPhoneBookRowID", userPhoneBookRowID);

            using (var connection = new SqliteConnection(_getConnectionString()))
            {
                await connection.ExecuteAsync("UPDATE UserPhoneBook SET IsActive = 0 WHERE rowId=@UserPhoneBookRowID;" +
                "", parameterForUser);
            }
        }



    }

}
