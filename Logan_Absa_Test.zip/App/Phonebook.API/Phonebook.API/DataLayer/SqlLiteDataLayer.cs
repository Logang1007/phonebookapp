﻿using Dapper;
using Microsoft.Data.Sqlite;
using Microsoft.Extensions.Options;
using Phonebook.API.Interface;
using Phonebook.API.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Phonebook.API.DataLayer
{
    public class SqlLiteDataLayer: IDataLayer
    {
        private string _connectionString { get; set; }
        public void SetDBConnection(string connectionString, bool useInMem = false)
        {
            if (useInMem)
            {
                _connectionString = connectionString;
            }
            else{
                var conn = Phonebook.API.Helpers.Constants.GetDBPath(connectionString);
                _connectionString = conn;
            }
          
        }

        public void Setup()
        {
    

            using var connection = new SqliteConnection(_connectionString);

            var tableUserPhoneBook = connection.Query<string>("SELECT name FROM sqlite_master WHERE type='table' AND name = 'UserPhoneBook';");
            var tableNameUserPhoneBook = tableUserPhoneBook.FirstOrDefault();
            if (!string.IsNullOrEmpty(tableNameUserPhoneBook) && tableNameUserPhoneBook == "UserPhoneBook")
            {
                return;
            }
           

            connection.Execute("Create Table UserPhoneBook (" +
                "UserID INT NOT NULL," + // this is the rowid from Users table
                "EntryID INT NOT NULL," + // this is the rowid from PhoneBookEntry table
                "DateAdded DATETIME NOT NULL," +
                "IsActive BIT NOT NULL);");


            var tableEntry = connection.Query<string>("SELECT name FROM sqlite_master WHERE type='table' AND name = 'PhoneBookEntry';");
            var tableNameEntry = tableEntry.FirstOrDefault();
            if (!string.IsNullOrEmpty(tableNameEntry) && tableNameEntry == "PhoneBookEntry")
            {
                return;
            }


            connection.Execute("Create Table PhoneBookEntry (" +
                "Name VARCHAR(100) NOT NULL," +
                "PhoneNumber VARCHAR(100) NOT NULL," +
                "DateAdded DATETIME NOT NULL" +
                ");");


            var tableUser = connection.Query<string>("SELECT name FROM sqlite_master WHERE type='table' AND name = 'Users';");
            var tableNameUsers = tableUser.FirstOrDefault();
            if (!string.IsNullOrEmpty(tableNameUsers) && tableNameUsers == "Users")
            {
                return;
            }


            connection.Execute("Create Table Users (" +
                "Firstname VARCHAR(100) NOT NULL," +
                "Lastname VARCHAR(100) NOT NULL," +
                "Username VARCHAR(100) NOT NULL," +
                "Password VARCHAR(100) NOT NULL," +
                "DateAdded DATETIME NOT NULL" +
                ");");


        }

        
    }
}
