﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Phonebook.API.Filters;
using Phonebook.API.Interface;
using Phonebook.API.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Phonebook.API.Controllers
{
   
    [SecurityMiddleware]
    [ApiController]
    [Route("api/phonebook")]
    public class PhoneBookController : ControllerBase
    {

        private readonly ILogger<PhoneBookController> _logger;
        private readonly IPhonebookService _phonebookService;
        public PhoneBookController(ILogger<PhoneBookController> logger, IPhonebookService phonebookService)
        {
            _logger = logger;
            _phonebookService = phonebookService;
        }

        [ValidationFilter]
        [HttpPost("adduser")]
        public async Task<BaseResponseModel> AddUser([FromHeader] string ApiKey, [FromHeader] string MerchName, [FromBody] UserModel userModel)
        {
            var returnValue = new BaseResponseModel();
            try
            {
                returnValue = await _phonebookService.AddUser(userModel);
            }
            catch(Exception ex)
            {
                _logger.LogError("AddUser Error", ex);
                returnValue.IsSuccess = false;
                returnValue.Message = $"Internal System error, adding user.{ex.Message}";
                returnValue.Code = "C001";
            }


            return returnValue;
        }

        [HttpPost("login")]
        public async Task<UserResponseModel> LoginUser([FromHeader] string ApiKey, [FromHeader] string MerchName, [FromBody] UserLoginModel userLoginModel)
        {
            var returnValue = new UserResponseModel();
            try
            {
                returnValue = await _phonebookService.GetUserByCredentials(userLoginModel.Username, userLoginModel.Password);
            }
            catch (Exception ex)
            {
                _logger.LogError("LoginUser Error", ex);
                returnValue.IsSuccess = false;
                returnValue.Message = $"Internal System error, login user.{ex.Message}";
                returnValue.Code = "C002";
            }


            return returnValue;
        }

    

        [ValidationFilter]
        [HttpPost("entry/add")]
        public async Task<BaseResponseModel> AddUserPhoneBookEntry([FromHeader] string ApiKey, [FromHeader] string MerchName, [FromHeader] string Token, [FromBody] UserPhoneBookViewModel userPhoneBookViewModel)
        {
            var returnValue = new BaseResponseModel();
            try
            {
                userPhoneBookViewModel.Token = Token;
                returnValue = await _phonebookService.AddUserPhoneBookEntry(userPhoneBookViewModel);
            }
            catch (Exception ex)
            {
                _logger.LogError("AddUserPhoneBookEntry Error", ex);
                returnValue.IsSuccess = false;
                returnValue.Message = $"Internal System error, adding phonebook entry.{ex.Message}";
                returnValue.Code = "C003";
            }


            return returnValue;
        }

        [HttpGet("user/entries/{userid}")]
        public async Task<UserPhoneBookResponseModel> GetUserPhonebookEntries([FromHeader] string ApiKey, [FromHeader] string MerchName,[FromHeader] string Token, [FromRoute] int userid)
        {
            var returnValue = new UserPhoneBookResponseModel();
            try
            {
                if (string.IsNullOrEmpty(Token))
                {
                    return new UserPhoneBookResponseModel() { IsTokenExpired = true, Message = "No Token provided", Code = "C004.1" };
                }
                returnValue = await _phonebookService.GetPhonebookEntriesByUser(userid, Token);
            }
            catch (Exception ex)
            {
                _logger.LogError("GetUser Error", ex);
                returnValue.IsSuccess = false;
                returnValue.Message = $"Internal System error, user phonebook entries error.{ex.Message}";
                returnValue.Code = "C004";
            }


            return returnValue;
        }

        [ValidationFilter]
        [HttpPost("validatetoken")]
        public async Task<BaseResponseModel> ValidateToken([FromHeader] string ApiKey, [FromHeader] string MerchName, [FromHeader] string Token)
        {
            var returnValue = new BaseResponseModel();
            try
            {
                returnValue = _phonebookService.ValidateJWTToken(Token);
            }
            catch (Exception ex)
            {
                _logger.LogError("ValidateToken Error", ex);
                returnValue.IsTokenExpired = true;
                returnValue.IsSuccess = false;
                returnValue.Message = $"Internal System error, validate token.{ex.Message}";
                returnValue.Code = "C006";
            }


            return returnValue;
        }

        [ValidationFilter]
        [HttpGet("entry/remove/{userBookEntryId}")]
        public async Task<BaseResponseModel> DeleteUserPhoneBookEntry([FromHeader] string ApiKey, [FromHeader] string MerchName, [FromHeader] string Token, [FromRoute ]int userBookEntryId)
        {
            var returnValue = new BaseResponseModel();
            try
            {
                returnValue = await _phonebookService.DeleteUserPhoneBookEntry(userBookEntryId, Token);
            }
            catch (Exception ex)
            {
                _logger.LogError("AddUser Error", ex);
                returnValue.IsSuccess = false;
                returnValue.Message = $"Internal System error, removing user phonebook entry.{ex.Message}";
                returnValue.Code = "C007";
            }


            return returnValue;
        }
    }
}
