﻿using Microsoft.Extensions.Options;
using Phonebook.API.Helpers;
using Phonebook.API.Interface;
using Phonebook.API.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Phonebook.API.Services
{
    public class PhonebookService: IPhonebookService
    {

        private readonly AppSettingsModel _appSettingsModel;
        private readonly IPhonebookRepository _phonebookRepository;
        private readonly IEncryptionHelper _encryptionHelper;
        private readonly IJWTHelper _jWTHelper;

        public PhonebookService(IOptions<AppSettingsModel> appSettingsModel, IEncryptionHelper encryptionHelper,
            IPhonebookRepository phonebookRepository, IJWTHelper jWTHelper)
        {
            _appSettingsModel = appSettingsModel.Value;
            _encryptionHelper = encryptionHelper;
            _phonebookRepository = phonebookRepository;
            _jWTHelper = jWTHelper;
        }


        public BaseResponseModel ValidateJWTToken(string token)
        {
            var result = new BaseResponseModel();
            try
            {
                var isTokenValid = _jWTHelper.ValidateJWToken(token);
                if (!isTokenValid)
                {
                    result.IsSuccess = false;
                    result.Message = $"Login token expired or invalid";
                    result.Code = "B005";
                    result.IsTokenExpired = true;

                    return result;
                }

                return result;
            }
            catch (Exception ex)
            {
                result.IsSuccess = false;
                result.Message = $"Internal System error,.{ex.Message}";
                result.Code = "B006";
                result.IsTokenExpired = true;

                return result;
            }
            
        }

        public async Task<BaseResponseModel> AddUser(UserModel userModel)
        {
            var result = new BaseResponseModel();

            var findUser = await _phonebookRepository.GetUserByUsername(userModel.Username);
            if(findUser != null)
            {
                return new BaseResponseModel()
                {
                    IsSuccess = false,
                    Message = "Username is invalid",
                    Code = "B001"

                };
            }

            userModel.Password = _encryptionHelper.HashText(userModel.Password);
            await _phonebookRepository.CreateUser(userModel);

            return result;
        }

        public async Task<UserResponseModel> GetUserByCredentials(string userName, string passord)
        {
            var result = new UserResponseModel();
            string hashPassword = _encryptionHelper.HashText(passord);
            var findUser = await _phonebookRepository.GetUserByCredentials(userName, hashPassword);
            if (findUser == null)
            {
                return new UserResponseModel()
                {
                    IsSuccess = false,
                    Message = "Login failed",
                    Code = "B002"

                };
            }

            result.User = findUser;
            var token = _jWTHelper.GenerateJwtToken(userName);
            result.Token = token;
            return result;
        }

        public async Task<BaseResponseModel> AddUserPhoneBookEntry(UserPhoneBookViewModel userPhoneBookViewModel)
        {
            var result = new BaseResponseModel();
            var isTokenValid = ValidateJWTToken(userPhoneBookViewModel.Token);
            if (!isTokenValid.IsSuccess)
            {
                return new UserPhoneBookResponseModel()
                {
                    IsSuccess = false,
                    Code = result.Code,
                    IsTokenExpired = true,
                    Message = isTokenValid.Message
                };
            }
            var findUser = await _phonebookRepository.GetUserById(userPhoneBookViewModel.UserID);
            if (findUser == null)
            {
                return new BaseResponseModel()
                {
                    IsSuccess = false,
                    Message = "Username not found",
                    Code = "B003"
                };
            }
            await _phonebookRepository.CreateUserPhoneBookEntry(userPhoneBookViewModel);
            result.Token = userPhoneBookViewModel.Token;
            return result;
        }


        public async Task<UserPhoneBookResponseModel> GetPhonebookEntriesByUser(int userId, string token)
        {
            var result = new UserPhoneBookResponseModel();
            var isTokenValid = ValidateJWTToken(token);
            if (!isTokenValid.IsSuccess)
            {
                return new UserPhoneBookResponseModel()
                {
                    IsSuccess = false,
                    Code = result.Code,
                    IsTokenExpired = true,
                    Message = isTokenValid.Message
                };
            }
            var findUser = await _phonebookRepository.GetUserById(userId);
            if (findUser == null)
            {
                return new UserPhoneBookResponseModel()
                {
                    IsSuccess = false,
                    Message = "Username not found",
                    Code = "B004"

                };
            }
            var phoneEntries = await _phonebookRepository.GetEntriesByUser(userId);
            result.UserPhonebookEntries = phoneEntries;
            result.Token = token;
            return result;

        }


        public async Task<BaseResponseModel> DeleteUserPhoneBookEntry(int userBookEntryId, string token)
        {
            var result = new BaseResponseModel();
            var isTokenValid = ValidateJWTToken(token);
            if (!isTokenValid.IsSuccess)
            {
                return new BaseResponseModel()
                {
                    IsSuccess = false,
                    Code = result.Code,
                    IsTokenExpired = true,
                    Message = isTokenValid.Message
                };
            }
            await _phonebookRepository.DeleteUserPhoneBookEntry(userBookEntryId);

            return result;
        }
    }
}
