﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Phonebook.API.Interface
{
    public interface IJWTHelper
    {
        string GenerateJwtToken(string userName);
        bool ValidateJWToken(string token);
    }
}
