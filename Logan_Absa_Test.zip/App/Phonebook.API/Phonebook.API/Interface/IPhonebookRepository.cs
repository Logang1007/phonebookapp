﻿using Phonebook.API.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Phonebook.API.Interface
{
    public interface IPhonebookRepository
    {
        Task CreateUser(UserModel userModel);
        Task<UserModel> GetUserByUsername(string userName);

        Task<UserModel> GetUserByCredentials(string userName, string passwordHashed);
        Task<UserModel> GetUserById(int userId);
        Task CreateUserPhoneBookEntry(UserPhoneBookViewModel userPhoneBookViewModel);
        Task<List<UserPhoneBookViewModel>> GetEntriesByUser(int userId);

        Task DeleteUserPhoneBookEntry(int userPhoneBookRowID);
    }
}
