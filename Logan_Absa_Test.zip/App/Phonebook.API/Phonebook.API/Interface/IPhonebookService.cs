﻿using Phonebook.API.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Phonebook.API.Interface
{
    public interface IPhonebookService
    {
        Task<BaseResponseModel> AddUser(UserModel userModel);
        Task<UserResponseModel> GetUserByCredentials(string userName, string password);
        Task<BaseResponseModel> AddUserPhoneBookEntry(UserPhoneBookViewModel userPhoneBookViewModel);
        BaseResponseModel ValidateJWTToken(string token);
        Task<UserPhoneBookResponseModel> GetPhonebookEntriesByUser(int userId, string token);

        Task<BaseResponseModel> DeleteUserPhoneBookEntry(int userBookEntryId, string token);
    }
}
