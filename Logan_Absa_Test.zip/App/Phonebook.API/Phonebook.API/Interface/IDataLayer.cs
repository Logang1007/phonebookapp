﻿using Microsoft.Data.Sqlite;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Phonebook.API.Interface
{
    public interface IDataLayer
    {
        void SetDBConnection(string connectionString, bool useInMem = false);
        void Setup();
    }
}
