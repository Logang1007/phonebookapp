using Microsoft.Extensions.Options;
using Moq;
using Phonebook.API.DataLayer;
using Phonebook.API.DataLayer.Repositories;
using Phonebook.API.Helpers;
using Phonebook.API.Interface;
using Phonebook.API.Models;
using Phonebook.API.Services;
using System;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Xunit;

namespace PhoneBook.API.Test
{
    public class PhonebookTests
    {

        private string _jwtKey = "test3453546!!998756998765!";

        public void _tearDown()
        {
            var path = _getPath() + "\\TestDB\\PhonebookTestDB.sqlite";
            if (File.Exists(path))
            {
                File.Delete(path);
            }
        }

        private string _getPath()
        {
            var path = System.IO.Path.GetDirectoryName(
             System.Reflection.Assembly.GetExecutingAssembly().GetName().CodeBase).Replace("file:\\", "");
            return path;



        }

        private void _setupTestDB(string fullDbPath)
        {
           
            var sqlDataLayer = new SqlLiteDataLayer();
            sqlDataLayer.SetDBConnection(fullDbPath, true);
            sqlDataLayer.Setup();

         
        }


        [Fact]
        public async Task AddUserSuccessTest()
        {
            _tearDown();

            string _userName = "logan";
            string _password = "23444";

            var fullDbPath = $"Data Source={_getPath()}\\TestDB\\PhonebookTestDB.sqlite";

            _setupTestDB(fullDbPath);

            var jwt = new JWT();
            jwt.Issuer = "http://localhost";
            jwt.Audience = "http://localhost";
            jwt.Key = _jwtKey;
            var mockSettings = Options.Create<AppSettingsModel>(new AppSettingsModel()
            {
                IsInMemoryDB = true,
                LoginTokenExpiryMinutes = 60,
                Jwt = jwt,
                InMemoryDBPath = fullDbPath
            });


            var encryMock = new EncryptionHelper();

            var jwtMock = new JWTHelper(mockSettings);



            //add a user to test
            var repo = new PhonebookRepository(mockSettings);

            var phoneBookService = new PhonebookService(mockSettings, encryMock, repo, jwtMock);
            await phoneBookService.AddUser(new UserModel() { Firstname = "log", Lastname = "gov", Username = "logan", Password = "23444" });
            var result = await phoneBookService.AddUser(new UserModel() { Firstname = "log", Lastname = "gov", Username = "logan2", Password = "23444" });

            Assert.True(result.IsSuccess);

        }

        [Fact]
        public async Task AddUserFailTest()
        {
            _tearDown();

            string _userName = "logan";
            string _password = "23444";

            var fullDbPath = $"Data Source={_getPath()}\\TestDB\\PhonebookTestDB.sqlite";

            _setupTestDB(fullDbPath);

            var jwt = new JWT();
            jwt.Issuer = "http://localhost";
            jwt.Audience = "http://localhost";
            jwt.Key = _jwtKey;
            var mockSettings = Options.Create<AppSettingsModel>(new AppSettingsModel()
            {
                IsInMemoryDB = true,
                LoginTokenExpiryMinutes = 60,
                Jwt = jwt,
                InMemoryDBPath = fullDbPath
            });


            var encryMock = new EncryptionHelper();

            var jwtMock = new JWTHelper(mockSettings);



            //add a user to test
            var repo = new PhonebookRepository(mockSettings);

            var phoneBookService = new PhonebookService(mockSettings, encryMock, repo, jwtMock);
            await phoneBookService.AddUser(new UserModel() { Firstname = "log", Lastname = "gov", Username = "logan", Password = "23444" });
            var result = await phoneBookService.AddUser(new UserModel() { Firstname = "log", Lastname = "gov", Username = "logan", Password = "23444" });

            Assert.True(!result.IsSuccess);

        }

        [Fact]
        public async Task LoginUserSuccessTest()
        {
            _tearDown();

            string _userName = "logan";
            string _password = "23444";

            var fullDbPath = $"Data Source={_getPath()}\\TestDB\\PhonebookTestDB.sqlite";

            _setupTestDB(fullDbPath);

            var jwt = new JWT();
            jwt.Issuer = "http://localhost";
            jwt.Audience = "http://localhost";
            jwt.Key = _jwtKey;
            var mockSettings = Options.Create<AppSettingsModel>(new AppSettingsModel()
            {
                IsInMemoryDB = true,
                LoginTokenExpiryMinutes = 60,
                Jwt = jwt,
                InMemoryDBPath = fullDbPath
            });


            var encryMock = new EncryptionHelper();

            var jwtMock = new JWTHelper(mockSettings);



            //add a user to test
            var repo = new PhonebookRepository(mockSettings);

            var phoneBookService = new PhonebookService(mockSettings, encryMock, repo, jwtMock);
            await phoneBookService.AddUser(new UserModel() { Firstname = "log", Lastname = "gov", Username = "logan", Password = "23444" });
            var result = await phoneBookService.GetUserByCredentials(_userName, _password);

            Assert.True(result.IsSuccess);

        }

        [Fact]
        public async Task LoginUserFailTest()
        {
            _tearDown();

            string _userName = "logan";
            string _password = "234445";

            var fullDbPath = $"Data Source={_getPath()}\\TestDB\\PhonebookTestDB.sqlite";

            _setupTestDB(fullDbPath);

            var jwt = new JWT();
            jwt.Issuer = "http://localhost";
            jwt.Audience = "http://localhost";
            jwt.Key = _jwtKey;
            var mockSettings = Options.Create<AppSettingsModel>(new AppSettingsModel()
            {
                IsInMemoryDB = true,
                LoginTokenExpiryMinutes = 60,
                Jwt = jwt,
                InMemoryDBPath = fullDbPath
            });


            var encryMock = new EncryptionHelper();

            var jwtMock = new JWTHelper(mockSettings);



            //add a user to test
            var repo = new PhonebookRepository(mockSettings);

            var phoneBookService = new PhonebookService(mockSettings, encryMock, repo, jwtMock);
            await phoneBookService.AddUser(new UserModel() { Firstname = "log", Lastname = "gov", Username = "logan", Password = "23444" });
            var result = await phoneBookService.GetUserByCredentials(_userName, _password);

            Assert.True(!result.IsSuccess);

        }


        [Fact]
        public async Task AddUserPhoneBookEnterySuccessTest()
        {
            _tearDown();

            string _userName = "logan";
            string _password = "234445";

            var fullDbPath = $"Data Source={_getPath()}\\TestDB\\PhonebookTestDB.sqlite";

            _setupTestDB(fullDbPath);

            var jwt = new JWT();
            jwt.Issuer = "http://localhost";
            jwt.Audience = "http://localhost";
            jwt.Key = _jwtKey;
            var mockSettings = Options.Create<AppSettingsModel>(new AppSettingsModel()
            {
                IsInMemoryDB = true,
                LoginTokenExpiryMinutes = 60,
                Jwt = jwt,
                InMemoryDBPath = fullDbPath
            });


            var encryMock = new EncryptionHelper();

            var jwtMock = new JWTHelper(mockSettings);



            //add a user to test
            var repo = new PhonebookRepository(mockSettings);

            var phoneBookService = new PhonebookService(mockSettings, encryMock, repo, jwtMock);
            await phoneBookService.AddUser(new UserModel() { Firstname = "log", Lastname = "gov", Username = "logan", Password = "234445" });
            var user = await phoneBookService.GetUserByCredentials(_userName, _password);

            await phoneBookService.AddUserPhoneBookEntry(new UserPhoneBookViewModel() { UserID = user.User.UserID, EntryName = "Testbook", PhoneNumber = "0314046522", Token= user.Token });

            var result = await phoneBookService.GetPhonebookEntriesByUser(user.User.UserID, user.Token);
            var hasAny = result.UserPhonebookEntries.Any(a => a.PhoneNumber == "0314046522" && a.EntryName == "Testbook");
            Assert.True(hasAny);

        }


        [Fact]
        public async Task AddUserPhoneBookEnteryFailTest()
        {
            _tearDown();

            string _userName = "logan";
            string _password = "234445";

            var fullDbPath = $"Data Source={_getPath()}\\TestDB\\PhonebookTestDB.sqlite";

            _setupTestDB(fullDbPath);

            var jwt = new JWT();
            jwt.Issuer = "http://localhost";
            jwt.Audience = "http://localhost";
            jwt.Key = _jwtKey;
            var mockSettings = Options.Create<AppSettingsModel>(new AppSettingsModel()
            {
                IsInMemoryDB = true,
                LoginTokenExpiryMinutes = 60,
                Jwt = jwt,
                InMemoryDBPath = fullDbPath
            });


            var encryMock = new EncryptionHelper();

            var jwtMock = new JWTHelper(mockSettings);



            //add a user to test
            var repo = new PhonebookRepository(mockSettings);

            var phoneBookService = new PhonebookService(mockSettings, encryMock, repo, jwtMock);
            await phoneBookService.AddUser(new UserModel() { Firstname = "log", Lastname = "gov", Username = "logan", Password = "234445" });
            var user = await phoneBookService.GetUserByCredentials(_userName, _password);

            await phoneBookService.AddUserPhoneBookEntry(new UserPhoneBookViewModel() { UserID = user.User.UserID, EntryName = "Testbook", PhoneNumber = "0314046522", Token = user.Token });

            var result = await phoneBookService.GetPhonebookEntriesByUser(user.User.UserID, user.Token);
            var hasAny = result.UserPhonebookEntries.Any(a => a.PhoneNumber == "03140465226" && a.EntryName == "Testbookff");
            Assert.True(!hasAny);

        }
    }
}
