import { Component, Inject, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { DataService } from '../services/data.service';
import { AuthenticationService } from '../services/auth.service';
import { Router } from '@angular/router';
import { BaseResponseModel, UserPhoneBookViewModel, UserResponseModel } from '../models/service.model';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-phone-book',
  templateUrl: './phonebook.component.html'
})
export class PhoneBookComponent implements OnInit{
  phonebookEntriesOrig: Array<UserPhoneBookViewModel> = null;
  phonebookEntries: Array<UserPhoneBookViewModel> = null;
  addEntryForm: FormGroup;
  submitted = false;
  user: UserResponseModel = null;
  loading = false;
  showModal = false;
  showMessage = "";
  showAddEntryFooter = false;
  showModalAddEntry = false;
  error = "";
  successAddEntry = false;
  errorGeneral = "";

  constructor(private dataService: DataService, private authenticationService: AuthenticationService,
    private router: Router, private formBuilder: FormBuilder ) {

  }


  private getUserInfo() {
    if (this.authenticationService.isAuthenticated()) {

      this.user = JSON.parse(localStorage.getItem('currentUser')) as UserResponseModel;
    }

    return null;
  }


  async ngOnInit() {
    this.addEntryForm = this.formBuilder.group({
      entryName: ['', Validators.required],
      phoneNumber: ['', Validators.required],
    });
    this.getUserInfo();
    await this.getPhoneBookList();
  }

  get fields() { return this.addEntryForm.controls; }

  async getPhoneBookList() {
    try {
     
      let result = await this.dataService.getUserPhoneBook(this.user.user.userID);
      if (!result.isSuccess) {
        this.showMessage = result.message;
        this.showModal = true;
      }
      this.showModal = false;
      this.showMessage = "";
      this.phonebookEntries = result.userPhonebookEntries;
      this.phonebookEntriesOrig = this.phonebookEntries;
    } catch (e) {
      this.showMessage = e.message;
      this.showModal = true;
    }
  }

  addPhoneEntry() {
    this.showModalAddEntry = true;
  }

  async onAddSubmit() {
    let userId = this.user.user.userID;
    this.submitted = true;


    if (this.addEntryForm.invalid) {
      return;
    }

    this.loading = true;
    try {
      var result = (await this.dataService.addUserPhoneBookEntry(userId, this.fields.entryName.value, this.fields.phoneNumber.value)) as BaseResponseModel;
      if (result.isTokenExpired) {
        this.authenticationService.logoutNoEmit();
        this.router.navigate(['']).then(() => {
          window.location.reload();
        })
        return;
      }
      if (!result.isSuccess) {
        this.successAddEntry = false;
        this.error = result.message;
        return;
      }

      this.loading = false;
      this.successAddEntry = true;
      await this.getPhoneBookList();
      this.showModalAddEntry = false;
    } catch (e) {
      this.successAddEntry = false;
      this.error = e.message;;
      this.loading = false;

    }

  }

  closeAddEntry() {
    this.showModalAddEntry = false;
  }

  async removePhoneNumber(entry: UserPhoneBookViewModel) {
    try {
      var result = (await this.dataService.removeUserPhoneBookEntry(entry.userPhoneBookRowID)) as BaseResponseModel;
      if (result.isTokenExpired) {
        this.authenticationService.logoutNoEmit();
        this.router.navigate(['']).then(() => {
          window.location.reload();
        })
        return;
      }
      if (!result.isSuccess) {
        this.errorGeneral = result.message;
        return;
      }
      this.errorGeneral = "";
      await this.getPhoneBookList();
    } catch (e) {
      this.errorGeneral = e.message;;

    }
  }


  search(ele:any) {
    let value = ele.target.value;
    if (value.length > 2) {
      this.phonebookEntries = this.phonebookEntries.filter(x => (x.entryName.toLowerCase().indexOf(value.toLowerCase()) !== -1) ||
        (x.phoneNumber.toLowerCase().indexOf(value.toLowerCase()) !== -1));
    }

    if (value.length === 0) {
      this.phonebookEntries = this.phonebookEntriesOrig;
    }

  }

  async logOut() {
    this.authenticationService.logout();
    this.router.navigate(['login']).then(() => {
      window.location.reload();
    })
  }

}

