import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { BehaviorSubject, Observable } from 'rxjs';
import { map } from 'rxjs/operators';

import { environment } from '../../environments/environment';
import { BaseResponseModel, UserLoginModel, UserModel, UserResponseModel } from '../models/service.model';


@Injectable({ providedIn: 'root' })
export class AuthenticationService {
  private currentUserSubject: BehaviorSubject<UserResponseModel>;
  public currentUser: Observable<UserResponseModel>;

  constructor(private http: HttpClient) {
    this.currentUserSubject = new BehaviorSubject<UserResponseModel>(JSON.parse(localStorage.getItem('currentUser')));
    this.currentUser = this.currentUserSubject.asObservable();
  }

  public get currentUserValue(): UserResponseModel {
    return this.currentUserSubject.value;
  }

  async login(username: string, password: string) {
    var postData: UserLoginModel = {
      username: username,
      password: password
    };
    const headers = new HttpHeaders({ 'ApiKey': environment.apiKey, 'MerchName': environment.merchName });
    return this.http.post<any>(`${environment.apiUrl}api/phonebook/login`, postData, { headers: headers })
      .pipe(map(user => {
       
        localStorage.setItem('currentUser', JSON.stringify(user));
        this.currentUserSubject.next(user);
        return user;
      })).toPromise();
  }

  logout() {
    // remove user from local storage to log user out
    localStorage.removeItem('currentUser');
    this.currentUserSubject.next(null);
  }

  logoutNoEmit() {
    // remove user from local storage to log user out
    localStorage.removeItem('currentUser');
  }

  isAuthenticated() {
    // remove user from local storage to log user out
    let user = localStorage.getItem('currentUser');
    if (user) {
      return true;
    }

    return false;
  }


  async registerUser(username: string, password: string,
    firstname: string, lastname: string) {
    var postData: UserModel = {
      username: username,
      password: password,
      firstname: firstname,
      lastname: lastname
    };
    const headers = new HttpHeaders({ 'ApiKey': environment.apiKey, 'MerchName': environment.merchName });
    return this.http.post<any>(`${environment.apiUrl}api/phonebook/adduser`, postData, { headers: headers })
      .pipe(map(user => {
        return user;
      })).toPromise();
  }


}
