import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

import { environment } from '../../environments/environment';
import { UserPhoneBookResponseModel, BaseResponseModel, UserResponseModel, UserPhoneBookViewModel } from '../models/service.model';
import { map } from 'rxjs/operators';
import { AuthenticationService } from './auth.service';

@Injectable({ providedIn: 'root' })
export class DataService {
  constructor(private http: HttpClient, private authenticationService: AuthenticationService) { }

  private getUserToken() {
    let userDataToken = "";
    if (this.authenticationService.isAuthenticated()) {

      let user = JSON.parse(localStorage.getItem('currentUser')) as UserResponseModel;
      userDataToken = user.token;
      return userDataToken;
    }

    return null;
  }

  async getUserPhoneBook(userId: number): Promise<UserPhoneBookResponseModel> {

      const headers = new HttpHeaders({ 'ApiKey': environment.apiKey, 'MerchName': environment.merchName, 'Token': this.getUserToken() });
      let booksResult = (await this.http.get<any>(`${environment.apiUrl}api/phonebook/user/entries/${userId}`, { headers: headers })
        .pipe(map(user => {


          return user;
        })).toPromise()) as UserPhoneBookResponseModel;

   
      return booksResult;
  }

  async addUserPhoneBookEntry(userID: number, entryName: string, phoneNumber: string): Promise<BaseResponseModel> {
    var postData: UserPhoneBookViewModel = {
      userID: userID,
      entryName: entryName,
      phoneNumber: phoneNumber
    };


    const headers = new HttpHeaders({ 'ApiKey': environment.apiKey, 'MerchName': environment.merchName, 'Token': this.getUserToken() });
    let result = (await this.http.post<any>(`${environment.apiUrl}api/phonebook/entry/add`, postData, { headers: headers })
      .pipe(map(item => {


        return item;
      })).toPromise()) as BaseResponseModel;


    return result;
  }


  async removeUserPhoneBookEntry(userPhoneBookEntryRowId: number): Promise<BaseResponseModel> {

    const headers = new HttpHeaders({ 'ApiKey': environment.apiKey, 'MerchName': environment.merchName, 'Token': this.getUserToken() });
    let booksResult = (await this.http.get<any>(`${environment.apiUrl}api/phonebook/entry/remove/${userPhoneBookEntryRowId}`, { headers: headers })
      .pipe(map(user => {


        return user;
      })).toPromise()) as BaseResponseModel;


    return booksResult;
  }
  
}
