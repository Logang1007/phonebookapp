import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { UserResponseModel } from '../models/service.model';
import { AuthenticationService } from '../services/auth.service';

@Component({
  selector: 'app-nav-menu',
  templateUrl: './nav-menu.component.html',
  styleUrls: ['./nav-menu.component.css']
})
export class NavMenuComponent {
  isExpanded = false;
  isLoggedIn = false;
  userWelcomeMessage = "";
  showFooter = false;
  showModal = false;

  constructor(private authenticationService: AuthenticationService, private router: Router) {
    if (this.authenticationService.isAuthenticated()) {
      this.isLoggedIn = true;
      let user = JSON.parse(localStorage.getItem('currentUser')) as UserResponseModel ;
      this.userWelcomeMessage = `Welcome back ${user.user.firstname} ${user.user.lastname}`;
    }
  }

  collapse() {
    this.isExpanded = false;
  }

  toggle() {
    this.isExpanded = !this.isExpanded;
  }

  async logOut() {
    this.authenticationService.logoutNoEmit();
    this.showModal = true;
    window.setTimeout(() => {
      this.router.navigate(['']).then(() => {
        window.location.reload();
      })
    }, 300)
  }
}
