import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { first } from 'rxjs/operators';

import { AuthenticationService } from '../services/auth.service';
import { UserResponseModel } from '../models/service.model';

@Component({ templateUrl: 'login.component.html' })
export class LoginComponent implements OnInit {
  loginForm: FormGroup;
  loading = false;
  submitted = false;
  returnUrl: string;
  error = '';
  showFooter = false;
  showModal = false;

  constructor(
    private formBuilder: FormBuilder,
    private route: ActivatedRoute,
    private router: Router,
    private authenticationService: AuthenticationService
  ) {
    // redirect to home if already logged in
    if (this.authenticationService.currentUserValue) {
      this.router.navigate(['/']);
    }
  }

  ngOnInit() {
    this.loginForm = this.formBuilder.group({
      username: ['', Validators.required],
      password: ['', Validators.required]
    });


    this.returnUrl = this.route.snapshot.queryParams['returnUrl'] || '/';
  }


  get f() { return this.loginForm.controls; }

  async onSubmit() {
    this.submitted = true;


    if (this.loginForm.invalid) {
      return;
    }

    this.loading = true;
    try {
      var result = (await this.authenticationService.login(this.f.username.value, this.f.password.value)) as UserResponseModel;
      if (result.isSuccess) {
        this.error = "";
        this.showModal = true;
        window.setTimeout(() => {
          this.router.navigate(['']).then(() => {
            window.location.reload();
          }) }, 300)
       
      } else {
        this.error = result.message;
      }
      this.loading = false;
    } catch (e) {
      this.error = e.message;
      this.loading = false;
      this.showModal = false;
    }
  }
}
