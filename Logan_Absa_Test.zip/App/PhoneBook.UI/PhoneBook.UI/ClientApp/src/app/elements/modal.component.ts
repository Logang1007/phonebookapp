import { Component, Injectable, Input, OnInit, TemplateRef, ViewChild } from '@angular/core'
import { ModalConfig } from './modal.config'

@Component({
  selector: 'app-modal',
  templateUrl: './modal.component.html',
})
@Injectable()
export class ModalComponent implements OnInit {
  @Input("show") show: false
  @Input("showFooter") showFooter: true
  @Input("title") title: ""

  constructor() { }

  ngOnInit(): void { }

  open() {
   
  }

  close() {
    this.show = false;

  }

  dismiss() {
  
  }
}
